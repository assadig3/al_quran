package com.hag.al_quran.Juz

data class Juz(
    val number: Int,
    val name: String,
    val englishName: String,
    val pageNumber: Int
)