package com.hag.al_quran.model

data class Qari(
    val id: String,
    val name: String,
    val url: String
)
